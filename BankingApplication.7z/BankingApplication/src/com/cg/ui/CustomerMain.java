package com.cg.ui;

import java.util.Scanner;

import com.cg.Exception.CustomerException;
import com.cg.beans.Customer;
import com.cg.service.CustomerService;
import com.cg.service.ICustomerService;

public class CustomerMain {

	static Scanner sc = new Scanner(System.in);
	static ICustomerService customerService =new CustomerService();
	
	public static void main(String args[]) throws CustomerException {
	
		int accNum =0;int amt=0;boolean status= false;
		Customer customer=null;
		while(true)
		{
			System.out.println("WELCOME TO XYZ BANK");
			System.out.println("select a option and press enter");
			System.out.println("*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.WithDraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			System.out.println("*/*/*/*/*/*/*/*/*/*/*/*/**/*/*/*/*/*/*/*");
			switch(sc.nextInt())
			{
			case 1:
				while(customer==null)
				{
					customer=createCustObj();
				}
				customerService.addCustomer(customer);
				System.out.println("Account created successfully with Account number: "+customer.getAccountNo());
				customer=null;
				break;
			case 2:
				do{
					System.out.println("Enter account number");
					accNum=sc.nextInt();
					status=customerService.getBalance(accNum);
				}while(status==false);
				break;
				
				
			case 3:
				do
				{
					System.out.println("Enter account number");
					accNum=sc.nextInt();
					System.out.println("Enter ammount to be deposited");
					amt=sc.nextInt();
					status=customerService.deposit(amt, accNum);
				}while(status==false);
				break;
				
				
			case 4:
				do
				{
					System.out.println("Enter account number");
					accNum=sc.nextInt();
					System.out.println("Enter withdraw amount");
					amt=sc.nextInt();
					status=customerService.withdrawAmt(amt, accNum);
				}while(status==false);
				break;
			case 5:
				System.out.println("Enter sender account number");
				accNum=sc.nextInt();
				System.out.println("Enter reciver account number");
				int accnum2=sc.nextInt();
				System.out.println("Enter amount to be transfered");
				amt=sc.nextInt();
				customerService.fundTransfer(amt, accNum, accnum2);
				break;
			case 6:
				do{
				System.out.println("Enter account number");
				accNum=sc.nextInt();
				status=customerService.recentTransactions(accNum);
				}while(status==false);
				break;
			case 7:
				
				System.out.println("Thank you, Have a nice day");
				System.exit(0);
				
				break;
			default:
				System.out.println("invalid option try again");
			}
		}
	}
	
	public static Customer createCustObj() 
	{
		Customer customer=new Customer();
		
		System.out.println("enter customer name");
		customer.setName(sc.next());
		if (!(customer.getName().charAt(0)>='A' && customer.getName().charAt(0)<='Z'))
		{
			System.out.println("Invalid customer name try again");
			return null;
		}
		System.out.println("enter customer email ID");
		customer.setEmailId(sc.next());
		System.out.println("enter customer mobile number");
		customer.setCellno(sc.next());
		char a=customer.getCellno().charAt(0);
		if(customer.getCellno().length()!=10  &&  (a!=9 || a!=8 || a!=7 || a!=6))
		{
			System.out.println("Invalid mobile number");
			return null;
		}
		customer.setAccountNo((int)(Math.random()*10000));
		
		
		return customer;
	}
}



