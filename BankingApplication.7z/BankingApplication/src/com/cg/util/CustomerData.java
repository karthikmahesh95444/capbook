package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.beans.Customer;

public class CustomerData {

	public static Map<Integer, Customer> hm=new HashMap<>();
	
	static
	{
		hm.put(7493,  new Customer("Surya", "9789997486", "chopperlasurya6@gmail.com", 7493, 660f));
		hm.put(1234,  new Customer("Praksh", "9785662544", "saiprakash99@gmail.com", 1234, 18560f));
				
	}
	
}
