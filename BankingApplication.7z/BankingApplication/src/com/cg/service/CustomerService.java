package com.cg.service;


import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.Exception.CustomerException;
import com.cg.beans.Customer;
import com.cg.dao.CustomerDAO;
import com.cg.dao.ICustomerDAO;

public class CustomerService implements ICustomerService {
	
	ICustomerDAO customerDAO =new CustomerDAO();

	@Override
	public Customer addCustomer(Customer customer) throws CustomerException {
		customerDAO.addCustomer(customer);
		validateCustomer(customer);
		return customer;
	}
	
	//get balance method
	public boolean getBalance(int accno)
	{
		return customerDAO.getBalance(accno);
	}
	//deposit method
	@Override
	public boolean deposit(int amt,int accNo) {
		return customerDAO.deposit(amt, accNo);
	}
	
	//withdraw amount method
	@Override
	public boolean withdrawAmt(int amt, int accNo) {
		return customerDAO.withdrawAmt(amt, accNo);
	}
	//fund transfer method
	@Override
	public boolean fundTransfer(int amt, int acc1, int acc2) {
		return customerDAO.fundTransfer(amt, acc1, acc2);
	}
	//recent transfer
	@Override
	public boolean recentTransactions(int accNo) {
		return customerDAO.recentTransactions(accNo);
		
	}
	public void validateCustomer(Customer bean) throws CustomerException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating Customer name
		if(!(isValidName(bean.getName()))) {
			validationErrors.add("\n Customer Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		//Validating EmailId
		if(!(isValidEmailId(bean.getEmailId()))){
			validationErrors.add("\n emailId Should Be Greater Than 5 Characters \n");
		}
		//Validating Phone Number
		if(!(isValidCellno(bean.getCellno()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		
		if(!validationErrors.isEmpty())
			throw new CustomerException(validationErrors +"");
	}
	public boolean isValidName(String CustomerName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(CustomerName);
		return nameMatcher.matches();
	}
	public boolean isValidEmailId(String mailId) {
	    Pattern mailpattern=Pattern.compile("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$");
	    Matcher mailmatcher=mailpattern.matcher(mailId);
	    return mailmatcher.matches();
	}
	public boolean isValidCellno(String Cellno){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(Cellno);
		return phoneMatcher.matches();
		
	}
	
	
}
	
	

