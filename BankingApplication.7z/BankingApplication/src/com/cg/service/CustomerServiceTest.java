package com.cg.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.beans.Customer;
import com.cg.dao.CustomerDAO;
import com.cg.dao.ICustomerDAO;

class CustomerServiceTest {
Customer c = new Customer();
Customer c1 = new Customer();
ICustomerDAO customerDAO =new CustomerDAO();
    
	@BeforeEach
	void setUp() throws Exception {
		c.setName("Surya");
		c.setCellno("9789997486");
		c.setEmailId("surya@gmail.com");
		c.setAccountNo(4561);
		c.setBalance(1000.0);
		c1.setName("prakash");
		c1.setCellno("9789997321");
		c1.setEmailId("prakash@gmail.com");
		c1.setAccountNo(4581);
		c1.setBalance(2000.0);
		customerDAO.addCustomer(c);
		customerDAO.addCustomer(c1);
	}

	@AfterEach
	void tearDown() throws Exception {
		
	}

	@Test
    public void testAccount()
    {
		c=customerDAO.addCustomer(c);
        assertEquals("Surya",c.getName());
    }
	@Test
    public void testBalance()
    {
		        assertEquals(true,customerDAO.getBalance(4561));
    }
	@Test
    public void testDeposit()
    {
		        assertEquals(true,customerDAO.deposit(500, 4561));
    }
	@Test
    public void testWithdraw()
    {
		        assertEquals(true,customerDAO.withdrawAmt(200, 4561));
    }
	@Test
    public void testTransfer()
    {
		        assertEquals(true,customerDAO.fundTransfer(200,4561,4581));
    }
	
	}

