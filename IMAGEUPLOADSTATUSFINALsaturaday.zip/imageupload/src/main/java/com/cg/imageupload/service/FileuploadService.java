package com.cg.imageupload.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.validation.Valid;

import org.apache.tomcat.jni.File;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cg.imageupload.bean.Status;
import com.cg.imageupload.bean.WallPost;
import com.cg.imageupload.controller.FileUploadController;
import com.cg.imageupload.dao.ImageRepo;

@Service

public class FileuploadService implements IFileuploadService{

	private static final String UPLOAD_ROOT = "C:\\Users\\KACHITTU\\images/";
	private ImageRepo repository;
    private  ResourceLoader resourcelLoader;
	
	
	@Autowired
	public FileuploadService(ImageRepo repository,ResourceLoader resourceLoader) {
		this.repository=repository;
		this.resourcelLoader=resourceLoader;
	}
	
	public WallPost createImage(MultipartFile file, WallPost wallpost) throws IOException {
		//File convertFile = new File("C:\\Users\\KACHITTU\\images/"+file.getOriginalFilename());
		
		//convertFile.createNewFile();
		if(!file.isEmpty()) {
			Files.copy(file.getInputStream(), Paths.get(UPLOAD_ROOT,file.getOriginalFilename()));
			// byte[] bFile = new byte[(int) file.];
		}
		return repository.save(wallpost);
		
	}

	@Override
	public void delete(int id) {
		repository.deleteById(id);
		
	}

	@Override
	public WallPost update(@Valid WallPost wallpost) {
		WallPost wallpost1 = repository.findById(wallpost.getId()).get();
		//status1.setMessage(status.getMessage());
		wallpost1.setCommentsbox(wallpost.getCommentsbox());
		return repository.save(wallpost1);
	}

	
	
	
	
	
}
