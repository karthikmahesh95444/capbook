package com.cg.imageupload.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.imageupload.bean.Status;
import com.cg.imageupload.bean.WallPost;
import com.cg.imageupload.service.IFileuploadService;

@RestController
public class FileUploadController {
	
	@Autowired
	
	IFileuploadService fileupload;
	
	@RequestMapping(value ="/upload",
			method =RequestMethod.POST,
			consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public WallPost fileUpload(@RequestParam("file") MultipartFile file,WallPost wallpost) throws IOException {
		/*File convertFile = new File("C:\\Users\\KACHITTU\\images/"+file.getOriginalFilename());
		
			convertFile.createNewFile();
			try(FileOutputStream fout = new FileOutputStream(convertFile)) {
				fout.write(file.getBytes());
				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		return fileupload.createImage(file, wallpost);
		
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "deleted/{id}")
	public void delete(@PathVariable("id") int id) {
		fileupload.delete(id);

	}

	@RequestMapping(value = "wallpost/{id}", method = RequestMethod.PUT)
	public WallPost update(@Valid @RequestBody WallPost wallpost) {
		return fileupload.update(wallpost);
	}

	
}
