package com.cg.imageupload.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.imageupload.bean.Status;
import com.cg.imageupload.dao.IStatusRepo;

@Service

public class StatusServiceImpl implements IStatusService {

	@Autowired

	IStatusRepo statusObj;

	public List<Status> getAll() {

		return (List<Status>) statusObj.findAll();
	}

	public Status addStatus(Status status) {
		return statusObj.save(status);
	}

	public Status get(int id) {
		Optional<Status> optional = statusObj.findById(id);
		return optional.get();
	}

	public void delete(int id) {

		statusObj.deleteById(id);
	//	return "Status Successfully Deleted";
	}

	public Status update(Status status) {
		Status status1 = statusObj.findById(status.getId()).get();
		//status1.setMessage(status.getMessage());
		status1.setCommentsbox(status.getCommentsbox());
		return statusObj.save(status1);

	}

}
