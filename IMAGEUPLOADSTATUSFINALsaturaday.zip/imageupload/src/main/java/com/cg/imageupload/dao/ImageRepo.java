package com.cg.imageupload.dao;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.imageupload.bean.WallPost;

public interface ImageRepo extends JpaRepository<WallPost, Integer>{

	//WallPost getOne(LocalDateTime now);

}
